#!/usr/bin/env bash
# Build the GPL-3.0-or-later DOOM engine with fixed source and compiler revisions.
# Modified 2026-10-21 for pi-standalone: pinned source/toolchain and preserved runtime exports.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DOOM_DIR="$SCRIPT_DIR"
SOURCE_DIR="${DOOM_SOURCE_DIR:-$DOOM_DIR/doomgeneric}"
BUILD_DIR="${DOOM_BUILD_DIR:-$DOOM_DIR/build}"
DOOM_REVISION=cba6149f79d8b8bd80520097107d25e841bb3e0e
# Hash all 207 source/build/text inputs; four documentation screenshots are unused.
DOOM_TREE_SHA256=bc321152cc04ffd08a7fd465c4779d3561b85f49c131a1664c18b8f257ee48d8
EMSCRIPTEN_VERSION=4.0.22
EMSCRIPTEN_REVISION=0f3d2e62bccf8e14497ff19e05a1202c51eb0c65
EMSCRIPTEN_RELEASE=bebaf7e50e31865b0724f17eaa52e161e2dfef5a
EMCC="${EMCC:-emcc}"

echo "=== pi-doom Build Script ==="

# See ../README.md for installation of the pinned official SDK.
if ! command -v "$EMCC" &> /dev/null; then
    echo "Error: Emscripten $EMSCRIPTEN_VERSION is required (see ../README.md)." >&2
    exit 1
fi
COMPILER_VERSION="$("$EMCC" --version)"
if [[ "$COMPILER_VERSION" != *" $EMSCRIPTEN_VERSION ($EMSCRIPTEN_REVISION)"* ]]; then
    echo "Error: expected Emscripten $EMSCRIPTEN_VERSION ($EMSCRIPTEN_REVISION)." >&2
    exit 1
fi
EMSCRIPTEN_DIR="$(cd "$(dirname "$(command -v "$EMCC")")" && pwd -P)"
SDK_DIR="$(cd "$EMSCRIPTEN_DIR/../.." && pwd -P)"
if [[ -f "$SDK_DIR/upstream/.emsdk_version" ]] &&
    [[ "$(cat "$SDK_DIR/upstream/.emsdk_version")" != "releases-$EMSCRIPTEN_RELEASE-64bit" ]]; then
    echo "Error: Emscripten SDK release revision does not match the pinned build." >&2
    exit 1
fi

# Fetch only the fixed commit. Extracted corresponding-source archives work offline.
if [[ ! -d "$SOURCE_DIR" ]]; then
    git init "$SOURCE_DIR"
    git -C "$SOURCE_DIR" remote add origin https://github.com/ozkl/doomgeneric.git
    git -C "$SOURCE_DIR" fetch --depth 1 origin "$DOOM_REVISION"
    git -C "$SOURCE_DIR" -c advice.detachedHead=false checkout --detach FETCH_HEAD
fi
SOURCE_DIR="$(cd "$SOURCE_DIR" && pwd -P)"
if [[ -e "$SOURCE_DIR/.git" ]] &&
    [[ "$(git -C "$SOURCE_DIR" rev-parse HEAD)" != "$DOOM_REVISION" ]]; then
    echo "Error: doomgeneric must be at $DOOM_REVISION." >&2
    exit 1
fi
python3 - "$SOURCE_DIR" "$DOOM_TREE_SHA256" <<'PY'
import hashlib
import sys
from pathlib import Path

root = Path(sys.argv[1])
digest = hashlib.sha256()
excluded = {'screenshots/freebsd.png', 'screenshots/sdl.png',
            'screenshots/ubuntu.png', 'screenshots/windows.png'}
for path in sorted(p for p in root.rglob('*') if p.is_file() and
                   '.git' not in p.relative_to(root).parts and
                   p.relative_to(root).as_posix() not in excluded):
    digest.update(path.relative_to(root).as_posix().encode() + b'\0')
    digest.update(hashlib.sha256(path.read_bytes()).digest())
if digest.hexdigest() != sys.argv[2]:
    raise SystemExit('Error: doomgeneric source contents differ from the pinned tree.')
PY

# Create build directory
mkdir -p "$BUILD_DIR"

echo "Compiling DOOM to WebAssembly..."
cd "$SOURCE_DIR/doomgeneric"
BUILD_DIR="$(cd "$BUILD_DIR" && pwd -P)"
LINK_ARGS=()
if [[ "${DOOM_LINK_TRACE:-0}" == 1 ]]; then
    LINK_ARGS+=("-Wl,--trace" "-Wl,-Map,$BUILD_DIR/doom.map")
fi

# Resolution - 640x400 is doomgeneric default, good balance of speed/quality
RESX=${DOOM_RESX:-640}
RESY=${DOOM_RESY:-400}

echo "Resolution: ${RESX}x${RESY}"

# Compile with Emscripten (no sound)
export SOURCE_DATE_EPOCH=1765768776
"$EMCC" -O2 \
    "-ffile-prefix-map=$SOURCE_DIR=/doomgeneric" \
    "-ffile-prefix-map=$DOOM_DIR=/pi-doom" \
    "-ffile-prefix-map=$SDK_DIR=/emsdk" \
    -s WASM=1 \
    -s EXPORTED_FUNCTIONS="['_doomgeneric_Create','_doomgeneric_Tick','_DG_GetFrameBuffer','_DG_GetScreenWidth','_DG_GetScreenHeight','_DG_PushKeyEvent','_malloc','_free']" \
    -s EXPORTED_RUNTIME_METHODS="['ccall','cwrap','getValue','setValue','FS','FS_createDataFile','FS_createPath','HEAPU8','HEAPU32']" \
    -s ALLOW_MEMORY_GROWTH=1 \
    -s INITIAL_MEMORY=33554432 \
    -s MODULARIZE=1 \
    -s EXPORT_NAME="createDoomModule" \
    -s ENVIRONMENT='node' \
    -s FILESYSTEM=1 \
    -s FORCE_FILESYSTEM=1 \
    -s EXIT_RUNTIME=0 \
    -DDOOMGENERIC_RESX="$RESX" \
    -DDOOMGENERIC_RESY="$RESY" \
    -I. \
    am_map.c \
    d_event.c \
    d_items.c \
    d_iwad.c \
    d_loop.c \
    d_main.c \
    d_mode.c \
    d_net.c \
    doomdef.c \
    doomgeneric.c \
    "$DOOM_DIR/doomgeneric_pi.c" \
    doomstat.c \
    dstrings.c \
    f_finale.c \
    f_wipe.c \
    g_game.c \
    hu_lib.c \
    hu_stuff.c \
    i_cdmus.c \
    i_input.c \
    i_endoom.c \
    i_joystick.c \
    i_scale.c \
    i_sound.c \
    i_system.c \
    i_timer.c \
    i_video.c \
    icon.c \
    info.c \
    m_argv.c \
    m_bbox.c \
    m_cheat.c \
    m_config.c \
    m_controls.c \
    m_fixed.c \
    m_menu.c \
    m_misc.c \
    m_random.c \
    memio.c \
    p_ceilng.c \
    p_doors.c \
    p_enemy.c \
    p_floor.c \
    p_inter.c \
    p_lights.c \
    p_map.c \
    p_maputl.c \
    p_mobj.c \
    p_plats.c \
    p_pspr.c \
    p_saveg.c \
    p_setup.c \
    p_sight.c \
    p_spec.c \
    p_switch.c \
    p_telept.c \
    p_tick.c \
    p_user.c \
    r_bsp.c \
    r_data.c \
    r_draw.c \
    r_main.c \
    r_plane.c \
    r_segs.c \
    r_sky.c \
    r_things.c \
    s_sound.c \
    sha1.c \
    sounds.c \
    st_lib.c \
    st_stuff.c \
    statdump.c \
    tables.c \
    v_video.c \
    w_checksum.c \
    w_file.c \
    w_file_stdc.c \
    w_main.c \
    w_wad.c \
    wi_stuff.c \
    z_zone.c \
    dummy.c \
    "${LINK_ARGS[@]}" \
    -o "$BUILD_DIR/doom.js"

python3 - "$BUILD_DIR/doom.js" <<'PY'
import sys
from pathlib import Path

path = Path(sys.argv[1])
notice = ('/* DOOM engine: GPL-3.0-or-later; see ../LICENSE and ../source-provenance.json.\n'
          ' * Rebuilt 2026-10-21 for pi-standalone: pinned source/toolchain and preserved runtime exports.\n'
          ' * Generated Emscripten runtime retains its separate permissive notices.\n'
          ' * Complete source: scripts/standalone-notices/doom-corresponding-source.tar.gz\n'
          ' */\n')
path.write_bytes(notice.encode() + path.read_bytes())
PY

echo ""
echo "Build complete!"
echo "Output: $BUILD_DIR/doom.js and $BUILD_DIR/doom.wasm"
