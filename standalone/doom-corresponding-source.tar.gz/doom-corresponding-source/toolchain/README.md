# Pinned compiler and runtime source

The build uses official Emscripten 4.0.22 (commit
0f3d2e62bccf8e14497ff19e05a1202c51eb0c65), installed with official emsdk tag
4.0.22 (commit 15915cad554b707837024dc2758b6a1c5b94b036), binary release
bebaf7e50e31865b0724f17eaa52e161e2dfef5a. Exact upstream URLs, source tar SHA-256,
build entrypoint hash, invocation and output hashes are in
../doom/source-provenance.json. That official source tar was used to extract
the retained source; retained files were compared against the installed SDK.
The SDK normalizes emscripten-version.txt from the source tag's 4.0.22-git
to released 4.0.22; both the actual installed value and original upstream
value (emscripten-version.upstream.txt) are preserved. Runtime code is exact.

emscripten-4.0.22 contains preferred JS runtime source, C runtime/header source
for the linked libc/musl, dlmalloc and compiler-rt families, required compiler
helpers, and their original license/copyright files. runtime-sources.json lists
every retained source hash and maps every linked runtime archive member to
included preferred source. The normalized linker trace/map is in ../link.
No compiler executable, object/archive library, test/demo/media fixture, font,
game WAD, or unrelated Emscripten port is included. The compiler is a standard
build tool installed separately from the fixed official release.

The emsdk installer and its pinned manifests/license are included for review.
Only its precompiled release component is needed; this does not invoke its
SDK npm post-install path. Use an existing supported Node installation
(v24.1.0 was used for the distributed assets).
