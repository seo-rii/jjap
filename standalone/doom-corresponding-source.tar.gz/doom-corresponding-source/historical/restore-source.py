import hashlib
import json
import os
import sys
from pathlib import Path

root = Path(__file__).resolve().parent / 'doomgeneric-source-history'
index = json.loads((root / 'index.json').read_text())
commit = next(row for row in index['commits'] if row['original_commit'] == sys.argv[1])
destination = Path(sys.argv[2]).resolve()
destination.mkdir(parents=True, exist_ok=False)
for file in commit['files']:
    blob = index['blobs'][file['original_blob']]
    if 'stored_source' not in blob:
        continue
    content = (root / blob['stored_source']).read_bytes()
    assert hashlib.sha256(content).hexdigest() == blob['sha256']
    assert hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest() == file['original_blob']
    target = destination / file['path']
    assert target.resolve().is_relative_to(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    if file['mode'] == '120000':
        link = content.decode()
        assert not Path(link).is_absolute() and (target.parent / link).resolve().is_relative_to(destination)
        target.symlink_to(link)
    else:
        target.write_bytes(content)
        target.chmod(0o755 if file['mode'] == '100755' else 0o644)
print(commit['original_commit'])
