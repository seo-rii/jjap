# Public historical materials

These files document the inherited Pi v1.3.0 example before its pinned rebuild.
The original adapter and binaries match public pi-doom commit
c209a539e0b0a157b96da7b4c535fbbad7af11dd. Exact original public build and adapter
files, package license metadata, README, and inherited asset hashes/Git blobs
are preserved. Pi's inherited build.sh differs only in its portable shebang and
quoted resolution definitions; that exact inherited script is included too.

doomgeneric-source-history contains source-only snapshots for all reachable
public commits through 2026-01-07, ending at
cba6149f79d8b8bd80520097107d25e841bb3e0e. Every historical source text blob,
including C/H/assembly/build/config/license inputs, is preserved. The index
records original commit/tree/parent/blob IDs, modes, all paths, original file
SHA-256/sizes, stored source blobs, and explicitly excluded entries.

WAD game data, compiled executables and other binary assets are excluded.
These filtered snapshots are not original or rewritten Git objects; there is
no Git bundle in this archive. All 207 current source/build/text inputs are
preserved under ../doom/doomgeneric. Four documentation-only screenshots are
omitted; original full 211-file tree hash and exact excluded asset hashes are
recorded in ../doom/source-provenance.json.

The inherited binary had no recorded engine/compiler pins. These public
materials do not reconstruct unknown private edits or prove exact reproduction
of the inherited binary. The rebuildable source under ../doom corresponds to
the new distributed assets identified by ../doom/source-provenance.json.

Restore any indexed historical source snapshot with:

    python3 restore-source.py ORIGINAL_COMMIT /new/output/directory
