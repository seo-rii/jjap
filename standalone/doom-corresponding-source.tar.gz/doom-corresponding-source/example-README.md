# DOOM Overlay Demo

Play DOOM as an overlay in pi. Demonstrates that the overlay system can handle real-time game rendering at 35 FPS.

## Usage

```bash
pi --extension ./examples/extensions/doom-overlay
```

Then run:
```
/doom-overlay
```

The shareware WAD file (~4MB) is auto-downloaded on first run.

## Controls

| Action | Keys |
|--------|------|
| Move | WASD or Arrow Keys |
| Run | Shift + WASD |
| Fire | F or Ctrl |
| Use/Open | Space |
| Weapons | 1-7 |
| Map | Tab |
| Menu | Escape |
| Pause/Quit | Q |

## How It Works

DOOM runs as WebAssembly compiled from [doomgeneric](https://github.com/ozkl/doomgeneric). Each frame is rendered using half-block characters (▀) with 24-bit color, where the top pixel is the foreground color and the bottom pixel is the background color.

The overlay uses:
- `width: "90%"` - 90% of terminal width
- `maxHeight: "80%"` - Maximum 80% of terminal height
- `anchor: "center"` - Centered in terminal

Height is calculated from width to maintain DOOM's 3.2:1 aspect ratio (accounting for half-block rendering).

## Credits

- [id Software](https://github.com/id-Software/DOOM) for the original DOOM
- [doomgeneric](https://github.com/ozkl/doomgeneric) for the portable DOOM implementation
- [pi-doom](https://github.com/badlogic/pi-doom) for the original pi integration

## Source, License, and Rebuilding

The bundled engine was rebuilt for pi-standalone from doomgeneric commit
`cba6149f79d8b8bd80520097107d25e841bb3e0e` with Emscripten **4.0.22**
(`0f3d2e62bccf8e14497ff19e05a1202c51eb0c65`). It retains the 640×400 framebuffer,
keyboard API, and sound-free platform adapter. The combined engine is
**GPL-3.0-or-later**, including its GPL-3.0-or-later `sha1.c`; the generated and
linked standard-library runtime retains its separate permissive notices.
See [doom/LICENSE](doom/LICENSE) and [doom/source-provenance.json](doom/source-provenance.json).

The complete [corresponding-source archive](../../../../../scripts/standalone-notices/doom-corresponding-source.tar.gz)
is also distributed as the release asset `doom-corresponding-source.tar.gz`.
It includes the pinned engine tree, actual adapter/build script, runtime source,
licenses, hashes, and separately labeled public historical materials. Game WAD
data and compiler executables are excluded.

Install the official pinned SDK in a directory of your choice, using an existing
Node installation and the precompiled release component:

```bash
git clone --depth 1 --branch 4.0.22 https://github.com/emscripten-core/emsdk.git emsdk
git -C emsdk rev-parse HEAD
# Must print 15915cad554b707837024dc2758b6a1c5b94b036.
cd emsdk
./emsdk install releases-bebaf7e50e31865b0724f17eaa52e161e2dfef5a-64bit
./emsdk activate releases-bebaf7e50e31865b0724f17eaa52e161e2dfef5a-64bit
source ./emsdk_env.sh
```

Then run `bash doom/build.sh` from this example directory. The script validates
both the compiler revision and complete engine source contents. It fetches only
the fixed engine commit when source is absent. For an offline rebuild, extract
the corresponding-source archive and run `bash doom/build.sh` from its root;
the engine source is already present. `DOOM_SOURCE_DIR` and `DOOM_BUILD_DIR`
can select other absolute input and output directories. `DOOM_RESX` and
`DOOM_RESY` retain the optional resolution overrides; defaults reproduce the
distributed assets. Set `DOOM_LINK_TRACE=1` to emit a linker trace and `doom.map`
for runtime source review.
