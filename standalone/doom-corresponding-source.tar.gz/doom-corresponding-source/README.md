# Complete corresponding source for the rebuilt DOOM example

This source corresponds to doom.js and doom.wasm whose exact SHA-256 and sizes
are recorded in doom/source-provenance.json. The combined engine is
GPL-3.0-or-later; original file-level engine and separate permissive runtime
notices are retained. License texts are in LICENSES and doom/LICENSE.

doom/doomgeneric contains all 207 unmodified source/build/text inputs from the
pinned upstream tree. Four unused documentation screenshots are omitted; their
exact paths/hashes and original full 211-file tree hash are in the provenance.
doom/doomgeneric_pi.c is the actual sound-free platform adapter, and
doom/build.sh is the actual pinned build script used for the distributed
640x400 assets. Neither the adapter nor engine C source was changed by the
rebuild. The build script and generated JS identify the rebuild date.

Install the exact official compiler as described in example-README.md and
toolchain/README.md. With emcc on PATH, run from this extracted directory:

    bash doom/build.sh

Engine source is included, so this step performs no source download. The
compiler must already be installed. Outputs are doom/build/doom.js and
doom/build/doom.wasm. DOOM_BUILD_DIR can select another absolute output path.
The script verifies compiler revision and all engine source contents, and
remaps compilation paths. Defaults reproduce the distributed asset hashes;
optional resolution overrides intentionally produce different builds.

To verify all extracted input hashes:

    sha256sum --check MANIFEST.sha256

Optional local smoke test with a separately obtained shareware IWAD:

    node smoke.mjs doom/build /absolute/path/to/doom1.wad

Game data is not included in this archive. Historical public material under
historical/ is labeled separately and makes no claim to reconstruct unknown
private changes used for the inherited unpinned binary.
