import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join, resolve } from 'node:path';
import { setTimeout } from 'node:timers/promises';

const buildDir = resolve(process.argv[2]);
const wad = readFileSync(process.argv[3]);
assert.equal(wad.subarray(0, 4).toString(), 'IWAD');
const filename = join(buildDir, 'doom.js');
const holder = { exports: {} };
new Function('module', 'exports', '__dirname', '__filename', 'require', readFileSync(filename, 'utf8'))(
  holder, holder.exports, buildDir, filename, createRequire(filename),
);
const output = [];
const module = await holder.exports({
  wasmBinary: readFileSync(join(buildDir, 'doom.wasm')),
  print: (message) => output.push(message),
  printErr: (message) => output.push(message),
  preRun: [(instance) => {
    instance.FS_createPath('/', 'doom', true, true);
    instance.FS_createDataFile('/doom', 'doom1.wad', wad, true, false);
  }],
});
const functions = ['_doomgeneric_Create', '_doomgeneric_Tick', '_DG_GetFrameBuffer', '_DG_GetScreenWidth', '_DG_GetScreenHeight', '_DG_PushKeyEvent', '_malloc', '_free', 'ccall', 'cwrap', 'setValue', 'getValue', 'FS_createPath', 'FS_createDataFile'];
for (const name of functions) assert.equal(typeof module[name], 'function', name);
assert.ok(module.HEAPU8 instanceof Uint8Array);
assert.ok(module.HEAPU32 instanceof Uint32Array);
assert.ok(module.FS);
const args = ['doom', '-iwad', '/doom/doom1.wad'];
const pointers = args.map((arg) => {
  const data = Buffer.from(`${arg}\0`);
  const pointer = module._malloc(data.length);
  module.HEAPU8.set(data, pointer);
  return pointer;
});
const argv = module._malloc(pointers.length * 4);
pointers.forEach((pointer, index) => module.setValue(argv + index * 4, pointer, 'i32'));
module._doomgeneric_Create(args.length, argv);
pointers.forEach((pointer) => module._free(pointer));
module._free(argv);
assert.equal(module._DG_GetScreenWidth(), 640);
assert.equal(module._DG_GetScreenHeight(), 400);
const pointer = module._DG_GetFrameBuffer();
assert.ok(pointer > 0 && pointer + 640 * 400 * 4 <= module.HEAPU8.length);
const frame = () => module.HEAPU8.slice(pointer, pointer + 640 * 400 * 4);
for (let i = 0; i < 8; i++) { await setTimeout(35); module._doomgeneric_Tick(); }
const before = frame();
assert.ok(before.some((byte) => byte !== 0), 'nonempty framebuffer');
module._DG_PushKeyEvent(1, 27);
for (let i = 0; i < 3; i++) { await setTimeout(35); module._doomgeneric_Tick(); }
module._DG_PushKeyEvent(0, 27);
const after = frame();
assert.notDeepEqual(after, before, 'Escape menu input updates frame');
module._DG_PushKeyEvent(1, 0xaf);
await setTimeout(35);
module._doomgeneric_Tick();
module._DG_PushKeyEvent(0, 0xaf);
assert.ok(output.some((line) => line.includes('DOOM Shareware')), 'real WAD recognized');
console.log(JSON.stringify({ node: process.version, dimensions: [640, 400], exportedFunctions: functions.length, framebufferBytes: before.length, before: createHash('sha256').update(before).digest('hex'), afterEscape: createHash('sha256').update(after).digest('hex'), input: 'Escape press/release + down press/release', wadBytes: wad.length }, null, 2));
